from django.apps import AppConfig


class SsssConfig(AppConfig):
    name = 'ssss'

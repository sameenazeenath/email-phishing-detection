from django.apps import AppConfig


class Request1Config(AppConfig):
    name = 'request1'
